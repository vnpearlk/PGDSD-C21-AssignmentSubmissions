package com.sweethome.bookingservice.constants;


/**
 * Supported Payment Modes.
 */
public enum PaymentMode {
    UPI,
    CARD
}
