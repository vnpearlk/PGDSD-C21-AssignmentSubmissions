package com.sweethome.paymentservice.constants;


/**
 * Message Constants
 */
public class Messages {

    public static final String INVALID_MODE_OF_PAYMENT = "Invalid mode of payment";

    public static final String INVALID_BOOKING_ID = "Invalid Booking Id";

}
