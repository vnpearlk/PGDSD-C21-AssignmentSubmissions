package com.sweethome.paymentservice.constants;


/**
 * Supported Payment Modes.
 */
public enum PaymentMode {
    UPI,
    CARD
}
